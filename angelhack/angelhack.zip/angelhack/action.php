
<form action="process.php" method="post"> 
 Your Name: <input type="text" name="name"><br> 
 E-mail: <input type="text" name = "email"><br> 
 Location: <input type="text" name = "location"><br> 
 <input type="submit" value="Submit"> 
 </form> 